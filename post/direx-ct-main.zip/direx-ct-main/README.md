# direx-ct
3d scanner
